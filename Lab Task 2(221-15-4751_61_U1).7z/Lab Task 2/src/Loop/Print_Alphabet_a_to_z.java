package Loop;

import java.util.Scanner;
public class Print_Alphabet_a_to_z {
	
	public static void main(String args[])
	{
		char i;
		for(i='a'; i<='z'; i++)
		{
			System.out.printf( i + " " );

		}
		
	}

}
